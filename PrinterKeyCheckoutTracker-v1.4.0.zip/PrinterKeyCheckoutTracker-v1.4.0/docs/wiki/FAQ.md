# FAQ

## Do users need local access to one person’s machine?

No. Data is stored in the shared Google Drive folder, not on one machine.

## Does each user need their own OAuth app?

No. One shared OAuth Desktop client can be used by all authorized users.

## Does each user still sign in personally?

Yes. Each user signs in with their own Google account.

## Can users with different Gmail addresses use it?

Yes, if they have been granted editor access to the shared Drive folder and are allowed by OAuth consent settings.

## Is data append-only?

Yes for event logs. Each event is appended to per-user CSV files.

## How is “What’s Out” calculated?

By scanning all log CSVs and selecting the latest event per `KeyId`.

## Does it prevent duplicate checkout?

Yes. Checkout is blocked if latest key state is already `OUT`.

## Where is the export file?

`<drive folder>/output/keylog_aggregate.xlsx`

## Does this require paid Google services?

For typical low-volume usage, usually no. Standard Google account limits apply.

## Where are local settings and tokens stored?

- macOS: `~/Library/Application Support/PrinterKeyCheckoutTracker/`
- Windows: `%APPDATA%\\PrinterKeyCheckoutTracker\\`
- Linux: `~/.config/PrinterKeyCheckoutTracker/`
