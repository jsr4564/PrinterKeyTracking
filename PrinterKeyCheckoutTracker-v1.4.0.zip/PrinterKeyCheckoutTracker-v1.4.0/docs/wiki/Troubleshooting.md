# Troubleshooting

Common problems and fixes.

## OAuth: `Error 403 access_denied`

Cause:

- OAuth consent screen or test-user setup is incomplete.

Fix:

1. Enable Google Drive API.
2. Confirm OAuth client type is **Desktop app**.
3. If consent is in Testing mode, add user under **Test users**.
4. Delete local token cache and retry sign-in.

Token cache locations:

- macOS: `~/Library/Application Support/PrinterKeyCheckoutTracker/google_token.json`
- Windows: `%APPDATA%\\PrinterKeyCheckoutTracker\\google_token.json`
- Linux: `~/.config/PrinterKeyCheckoutTracker/google_token.json`

## “Key already checked out”

Cause:

- Latest event for that key is `OUT`.

Fix:

- Use **What’s Out** to find current holder/time.
- Submit a return event before another checkout.

## Return warning: key is not currently out

Cause:

- No current `OUT` state exists for that `KeyId`.

Fix:

- Confirm key ID spelling.
- Continue only if you intentionally need to correct state.

## Export failed

Cause:

- Drive permission issue, connectivity issue, or malformed rows.

Fix:

- Verify you still have edit access to the shared folder.
- Retry after reconnecting network.
- Review warning details shown by the app.

## App won’t start (missing packages)

Fix:

```bash
python3 -m pip install -r requirements.txt
```

## Wrong account signed in

Fix:

- Remove local token cache file.
- Relaunch app and sign in with correct account.
