# Release Notes

This page tracks notable user-facing changes.

## Latest Release

### v1.3.0 (2026-02-22)

Highlights:

- Switched backend to Google OAuth + Google Drive storage.
- Added multi-user shared-folder event logging using per-user append-only CSV files.
- Added outstanding-key computation and double-checkout prevention.
- Added export to `keylog_aggregate.xlsx` with `RawEvents` and `WhatsOut` sheets.
- Added portable Python distribution scripts and zip packaging flow.
- Added app icon assets and updated documentation/wiki.

## Compatibility

- Python 3.10+
- macOS, Windows, Linux (source run)

## Upgrade Notes

- Existing users should re-authenticate with Google if prompted.
- If OAuth settings changed, clear local token cache and sign in again.

Token cache locations:

- macOS: `~/Library/Application Support/PrinterKeyCheckoutTracker/google_token.json`
- Windows: `%APPDATA%\\PrinterKeyCheckoutTracker\\google_token.json`
- Linux: `~/.config/PrinterKeyCheckoutTracker/google_token.json`

## Template For Next Release

```markdown
### vX.Y.Z (YYYY-MM-DD)

Highlights:
- Item 1
- Item 2

Fixes:
- Item 1

Notes:
- Any migration or auth changes
```
