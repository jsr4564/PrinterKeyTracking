# Printer Key Checkout Tracker

Welcome to the **Printer Key Checkout Tracker** wiki.

This project is a cross-platform Python desktop app (Tkinter) used to track printer key checkouts and returns in shared IT environments. It uses **Google OAuth** for sign-in and stores data in a shared **Google Drive folder** so multiple users can work from the same system of record.

Credits: Jack Shetterly

## What This App Does

- Records key checkout (`OUT`) and return (`IN`) events.
- Prevents double-checkout when a key is already out.
- Shows current outstanding keys with owner and checkout time.
- Exports a consolidated Excel report.
- Uses append-only per-user CSV event logs to reduce write conflicts.

## Core Workflow

1. Launch app.
2. Enter:
   - Google OAuth Desktop App Client ID
   - Google OAuth Desktop App Client Secret
   - Shared Google Drive folder URL (or folder ID)
3. Complete Google sign-in in browser.
4. Enter your session `UserId`.
5. Use the home actions:
   - **Check Out**
   - **Return**
   - **What’s Out**
   - **Export**

## Data Storage Model

The app creates and uses this structure inside the configured Drive folder:

```text
<drive folder>/
  logs/
    <userid>_events.csv
  output/
    keylog_aggregate.xlsx
```

CSV event schema:

`EventId, Timestamp, UserId, Action, KeyId, FromLocation, ToLocation, PrinterOrDestination, ReturnedToLocation, Notes`

## Security and Access

- Authentication is handled by Google OAuth (desktop flow).
- Each person signs in with their own Google account.
- Access to shared data depends on edit permission to the shared Drive folder.
- Local token/config cache is stored per user in OS app-data locations.

## Quick Start

1. Install Python 3.10+.
2. Install dependencies:

```bash
python3 -m pip install -r requirements.txt
```

3. Run:

macOS/Linux:

```bash
./run_mac_linux.sh
```

Windows:

```bat
run_windows.bat
```

## Export Details

Export writes:

- `output/keylog_aggregate.xlsx`

With sheets:

- `RawEvents` (all combined events)
- `WhatsOut` (`KeyId`, `CheckedOutBy`, `TimeOut`, `ToLocation`, `PrinterOrDestination`)

## Troubleshooting

### `403 access_denied` during sign-in

- Ensure Drive API is enabled in the Google Cloud project.
- Confirm OAuth consent screen configuration is complete.
- If app is in Testing, add users as test users.
- Remove stale local token cache and sign in again.

### “Key already checked out”

- The app detected latest state for that `KeyId` is `OUT`.
- Use **What’s Out** to confirm owner and timestamp.

### Export issues

- Verify write permissions to the shared Drive folder.
- Retry after ensuring network connectivity to Google services.

## Related Docs

- [README](../../README.md)

