# Admin Guide

This page is for the owner/maintainer of the shared deployment.

## Responsibilities

- Maintain Google Cloud OAuth configuration
- Maintain shared Drive folder permissions
- Distribute app package and setup instructions
- Validate export/report integrity

## OAuth Ownership

- Keep one stable Google Cloud project for the app.
- Use a **Desktop App** OAuth client.
- Configure consent screen correctly.
- If in testing mode, keep test users updated.

## Folder Access Model

- Keep one canonical shared Drive folder for all users.
- Grant users **Editor** access.
- Do not move/delete `logs/` and `output/` folders once in use.

## Operational Notes

- Event logs are append-only per user CSV files.
- No central database is required.
- The app computes current state by scanning all logs.

## Data Quality Controls

- Enforce consistent `UserId` naming convention.
- Enforce consistent `KeyId` naming convention.
- Encourage notes for exceptions.
- Review malformed row warnings during use/export.

## Security Guidance

- Treat OAuth client secret as sensitive configuration.
- Prefer secure channel for sharing setup values.
- Rotate client credentials if exposed.
- Revoke Drive access for former users.

## Suggested Maintenance Cadence

- Weekly: spot-check `WhatsOut` against physical inventory.
- Monthly: run export and archive a dated copy.
- Quarterly: review folder permissions and OAuth settings.
