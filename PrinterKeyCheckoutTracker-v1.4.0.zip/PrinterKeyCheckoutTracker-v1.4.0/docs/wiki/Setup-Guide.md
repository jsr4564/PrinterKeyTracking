# Setup Guide

This page covers first-time setup for the Printer Key Checkout Tracker.

## Prerequisites

- Python 3.10 or newer
- A Google account with access to the shared Drive folder
- Google OAuth Desktop App Client ID and Client Secret
- Shared Google Drive folder URL (or folder ID)

## 1) Create Google OAuth Desktop Credentials

1. Open Google Cloud Console.
2. Create or select a project.
3. Enable **Google Drive API**.
4. Configure **OAuth consent screen**.
5. Create credentials:
   - Type: **OAuth client ID**
   - Application type: **Desktop app**
6. Save:
   - `Client ID`
   - `Client Secret`

## 2) Prepare Shared Drive Folder

1. Create (or choose) one shared Google Drive folder.
2. Share it with all users as **Editor**.
3. Copy its URL.

The app creates this structure automatically:

```text
<drive folder>/
  logs/
    <userid>_events.csv
  output/
    keylog_aggregate.xlsx
```

## 3) Install and Run

Install dependencies:

```bash
python3 -m pip install -r requirements.txt
```

Run app:

macOS/Linux:

```bash
./run_mac_linux.sh
```

Windows:

```bat
run_windows.bat
```

## 4) First Launch Inputs

On first launch, enter:

- Google OAuth Desktop App Client ID
- Google OAuth Desktop App Client Secret
- Shared Google Drive folder URL (or folder ID)
- Session `UserId`

Then complete browser sign-in.

## 5) Optional Environment Variables

- `KEY_TRACKER_GOOGLE_CLIENT_ID`
- `KEY_TRACKER_GOOGLE_CLIENT_SECRET`
- `KEY_TRACKER_GOOGLE_FOLDER_URL`
- `KEY_TRACKER_GOOGLE_FOLDER_ID`

If set, these can prefill/override saved values.
