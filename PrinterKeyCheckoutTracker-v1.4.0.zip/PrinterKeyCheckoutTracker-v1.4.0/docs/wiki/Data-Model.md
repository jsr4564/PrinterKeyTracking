# Data Model

This page documents the event schema and computed outputs.

## Event Log Files

Path pattern:

```text
<drive folder>/logs/<userid>_events.csv
```

Each row is append-only.

## Event Columns

- `EventId`: UUID for each event row
- `Timestamp`: ISO 8601 timestamp
- `UserId`: actor submitting the event
- `Action`: `OUT` or `IN`
- `KeyId`: key identifier
- `FromLocation`: checkout origin (used by `OUT`)
- `ToLocation`: checkout destination (used by `OUT`)
- `PrinterOrDestination`: optional target context
- `ReturnedToLocation`: return destination (used by `IN`)
- `Notes`: optional free text

## Required by Action

For `OUT`:

- `KeyId`
- `FromLocation`
- `ToLocation`

For `IN`:

- `KeyId`
- `ReturnedToLocation`

## State Computation

Current key state is derived by:

1. Reading all CSV rows from all users.
2. Grouping rows by `KeyId`.
3. Selecting the latest row by timestamp.
4. Marking keys as out when latest action is `OUT`.

## Business Rules

- Prevent double-checkout when latest state is `OUT`.
- Return of non-out key requires user confirmation.
- Malformed rows are skipped and reported as warnings.

## Aggregated Export

Output path:

```text
<drive folder>/output/keylog_aggregate.xlsx
```

Sheets:

- `RawEvents`: all parsed events
- `WhatsOut`: outstanding keys with:
  - `KeyId`
  - `CheckedOutBy`
  - `TimeOut`
  - `ToLocation`
  - `PrinterOrDestination`
