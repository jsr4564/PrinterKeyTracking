# User Guide

This guide covers day-to-day use of the app.

## Sign In

1. Launch the app.
2. Enter Google OAuth credentials and shared Drive folder (if prompted).
3. Complete browser sign-in.
4. Enter your session `UserId`.

## Home Actions

- **Check Out**: create an `OUT` event
- **Return**: create an `IN` event
- **What’s Out**: view currently checked-out keys
- **Export**: generate combined Excel report

## Check Out

Required:

- `KeyId`
- `FromLocation`
- `ToLocation`

Optional:

- `PrinterOrDestination`
- `Notes`

If the key is already out, checkout is blocked and the app shows who has it and when it was checked out.

## Return

Required:

- `KeyId`
- `ReturnedToLocation`

Optional:

- `Notes`

If the key is not currently out, the app warns before allowing return submission.

## What’s Out

The list shows keys whose latest event is `OUT`, including:

- `KeyId`
- `CheckedOutBy`
- `TimeOut`
- `ToLocation`
- `PrinterOrDestination`

## Export

Export writes `keylog_aggregate.xlsx` to:

```text
<drive folder>/output/
```

Sheets:

- `RawEvents`
- `WhatsOut`

## Best Practices

- Use consistent `KeyId` format.
- Keep `UserId` stable across sessions.
- Add short notes for unusual moves/returns.
